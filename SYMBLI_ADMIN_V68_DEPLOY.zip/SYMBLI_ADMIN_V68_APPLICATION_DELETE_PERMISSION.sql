-- SYMBLI Admin V68
-- Allows ONLY the signed-in SYMBLI admin account to delete application records.
-- Run once in Supabase SQL Editor.
-- This does not delete any rows by itself.

alter table public.studio_applications enable row level security;

drop policy if exists "SYMBLI admin can delete applications"
on public.studio_applications;

create policy "SYMBLI admin can delete applications"
on public.studio_applications
for delete
to authenticated
using ((auth.jwt() ->> 'email') = 'symbli.uk@gmail.com');

grant delete on table public.studio_applications to authenticated;
